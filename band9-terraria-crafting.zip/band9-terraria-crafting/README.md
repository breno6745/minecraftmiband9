# BandCraft 2D — inventory + 2x2 crafting

Xiaomi Smart Band 9 / Vela JS.

This iteration keeps the fixed 192x490 viewport and the low-node renderer from the mobs build, adding:

- 10 inventory slots total, 5 visible at once.
- Inventory swipe up/down with the documented Vela `swipe` event.
- Item selection by tapping a visible slot.
- Steve-style 2x2 crafting grid (4 input slots).
- Recipes: 1 oak log -> 4 oak planks; 2 oak planks -> 4 sticks; 4 oak planks -> 1 crafting table.
- Crafting output is collected by tapping the result.
- Tapping a filled crafting slot returns its item to the inventory.
- Real texture files from the supplied Minecraft resource pack are used for blocks and crafting items.

Build:

```bat
npm install
npm run build
```

The game deliberately keeps the world renderer as a single image and limits live actor nodes to the four visible mob slots plus Steve.
