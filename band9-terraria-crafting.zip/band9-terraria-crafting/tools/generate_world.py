from PIL import Image, ImageDraw
import random, os

LOG_W, LOG_H = 96, 207
S = 24  # physical px per logical tile (12 logical px)
cols, rows = 8, 17
assert cols*S == 192 and rows*S == 408

img = Image.new('RGB',(cols*S, rows*S),(112,184,224))
d = ImageDraw.Draw(img)
random.seed(9)

# Minecraft-inspired placeholders; replace with supplied Mojang 16x16 textures later.
def tile(kind,x,y):
    x0,y0=x*S,y*S
    if kind=='dirt': base=(124,84,49)
    elif kind=='grass': base=(92,154,63)
    elif kind=='stone': base=(112,112,108)
    elif kind=='sand': base=(210,190,128)
    else: base=(80,140,60)
    d.rectangle([x0,y0,x0+S-1,y0+S-1],fill=base)
    # pixel texture, deliberately sparse
    for _ in range(22):
        px=x0+random.randrange(2,S-2,3); py=y0+random.randrange(2,S-2,3)
        if kind=='grass': c=random.choice([(78,142,53),(118,170,67),(72,130,48)])
        elif kind=='dirt': c=random.choice([(104,68,39),(145,96,56),(92,60,36)])
        elif kind=='stone': c=random.choice([(92,92,90),(133,133,128),(78,78,78)])
        elif kind=='sand': c=random.choice([(196,174,111),(225,205,145),(184,162,102)])
        else: c=(70,120,45)
        d.rectangle([px,py,px+2,py+2],fill=c)
    # hard block seam
    d.line([x0,y0,x0+S-1,y0], fill=(45,48,42), width=1)
    d.line([x0,y0,x0,y0+S-1], fill=(45,48,42), width=1)
    d.line([x0,y0+S-1,x0+S-1,y0+S-1], fill=(74,61,49), width=1)
    d.line([x0+S-1,y0,x0+S-1,y0+S-1], fill=(74,61,49), width=1)

# stepped terrain, one screen only
surface=[8,7,7,8,10,9,8,9]
for x,h in enumerate(surface):
    for y in range(h, rows):
        kind='grass' if y==h else ('dirt' if y<h+3 else 'stone')
        tile(kind,x,y)

# small exposed sand patch
for x in [5,6]:
    h=surface[x]
    tile('sand',x,h)

# tree trunks/leaves, aligned to tiles
for x,h in [(1,7),(6,8)]:
    # trunk in air above ground
    for yy in range(h-3,h):
        d.rectangle([x*S+8,yy*S+2,x*S+15,yy*S+S-3],fill=(111,72,43))
    for yy in range(h-4,h-2):
        for xx in range(max(0,x-1),min(cols,x+2)):
            tile('leaf',xx,yy)

# ore specks in stone blocks
for x in range(cols):
    for y in range(surface[x]+3, rows):
        if random.random()<0.18:
            px=x*S+random.randrange(4,S-5); py=y*S+random.randrange(4,S-5)
            d.rectangle([px,py,px+4,py+4],fill=(96,72,63))
            d.rectangle([px+1,py+1,px+3,py+3],fill=(164,104,67))

# crop to exact logical game area at 2x physical then nearest-neighbor
img = img.resize((LOG_W,LOG_H), Image.Resampling.LANCZOS)
os.makedirs('src/common',exist_ok=True)
img.save('src/common/world.png', optimize=True)

# Player: chunky pixel-art sprite, 14x20 logical => 28x40 physical
p=Image.new('RGBA',(28,40),(0,0,0,0)); q=ImageDraw.Draw(p)
# legs
q.rectangle([7,28,12,39], fill=(48,58,62,255)); q.rectangle([15,28,20,39], fill=(48,58,62,255))
# body
q.rectangle([5,15,22,30], fill=(43,126,168,255)); q.rectangle([8,18,19,28], fill=(57,151,192,255))
# head
q.rectangle([6,4,21,17], fill=(192,137,92,255)); q.rectangle([7,2,20,7], fill=(76,52,36,255))
q.rectangle([8,8,10,10], fill=(35,35,35,255)); q.rectangle([17,8,19,10], fill=(35,35,35,255))
p.save('src/common/player.png')
